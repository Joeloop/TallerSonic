#include "Planeta.h"
Planeta::Planeta(){}
Planeta::Planeta(string codPlaneta, string nombrePlaneta, string nombreGalaxia, int nivelPlaneta){
    this -> codPlaneta = codPlaneta;
    this -> nombrePlaneta = nombrePlaneta;
    this -> nombreGalaxia = nombreGalaxia;
    this -> nivelPlaneta = nivelPlaneta;
}
Planeta::~Planeta(){}
