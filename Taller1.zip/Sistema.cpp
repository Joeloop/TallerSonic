#include "Sistema.h"
#include <string>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <sstream>

using namespace std;

Sistema::Sistema(){   
}
Sistema::Sistema(int maxPrisioneros, int maxNaves, int maxPlanetas){
    this -> prisioneros = new ListaPrisioneros[maxPrisioneros];
    this -> naves = new ListaNaves[maxNaves];
    this -> planetas = new ListaPlaneta[maxPlanetas];  
}
Sistema::~Sistema(){}

void Sistema::leerArchivo()
{
    string line;
	ifstream text;
	text.open("Prisioneros.txt");

	if (text.fail()) { // Si no encuentra el archivo de texto se cierra el programa.
		cout << "\tNo se encontro el archivo Prisioneros.txt. \n" << endl;
		exit(EXIT_FAILURE);
	}
    int edad = 0;
    int nivelPrisionero = 0;
    while (!text.eof()) { // Mientras no sea el fin del texto
		getline(text, line);
		if (line != "") {
            string codPrisionero = "";
            string nombrePrisionero = "";
            string codNaveAsignada = "";

            istringstream space(line);
            
            getline(space, codPrisionero, ',');
            getline(space, nombrePrisionero, ',');
            getline(space, edad, ',');
            getline(space, nivelPrisionero, ',');
            getline(space, codNaveAsignada, ',');
            

        }
    } 
    text.close();

    text.open("Naves.txt");

	if (text.fail()) { // Si no encuentra el archivo de texto se cierra el programa.
		cout << "\tNo se encontro el archivo Prisioneros.txt. \n" << endl;
		exit(EXIT_FAILURE);
	}


    int cantActualTripulante = 0;
    int cantMaxTripulante = 0;
    while (!text.eof()) { // Mientras no sea el fin del texto
		getline(text, line);
		if (line != "") {
            string codNave = "";
            string nomNave = "";
            string codPlanetaDestino = "";
            //Hay que agregar el vector pero no se:(
            istringstream space(line);
            
            getline(space, codNave, ',');
            getline(space, nomNave, ',');
            getline(space, codPlanetaDestino, ',');
            getline(space, cantActualTripulante, ',');
            getline(space, cantMaxTripulante, ',');
            

        }
    } 
    text.close(); 

    text.open("Planetas.txt");

	if (text.fail()) { // Si no encuentra el archivo de texto se cierra el programa.
		cout << "\tNo se encontro el archivo Prisioneros.txt. \n" << endl;
		exit(EXIT_FAILURE);
	}

    int nivelPlaneta = 0;
    while (!text.eof()) { // Mientras no sea el fin del texto
		getline(text, line);
		if (line != "") {
            string codPlaneta = "";
            string nombrePlaneta = "";
            string nombreGalaxia = "";

            istringstream space(line);
            
            getline(space, codPlaneta, ',');
            getline(space, nombrePlaneta, ',');
            getline(space, nivelPlaneta, ',');
            getline(space, nombreGalaxia, ',');

        }
    } 
    text.close(); 
}
