#pragma once
#include <string>
using namespace std;
class Planeta{
public:
    Planeta();
    Planeta(string codPlaneta, string nombrePlaneta, string nombreGalaxia, int nivelPlaneta);
    ~Planeta();

    string getCodPlaneta();
public:
    string codPlaneta;
    string nombrePlaneta;
    string nombreGalaxia;
    int nivelPlaneta;
};