#pragma once
#include "Planeta.h"

class ListaPlanetas{
public :
    ListaPlanetas();
    ListaPlanetas(int max);        
    ~ListaPlanetas();

    bool agregarPlaneta(Planeta planeta);
    bool existe(string codPrisionero);
private:
    Planeta* lista;
    int cant;
    int max;
};