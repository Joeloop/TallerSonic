#include "Prisionero.h"
Prisionero::Prisionero() {}
Prisionero::Prisionero(string codPrisionero, string nombrePrisionero , string codNaveAsignada, int edad, int nivelPrisionero) {
    this -> codPrisionero = codPrisionero;
    this -> nombrePrisionero = nombrePrisionero;
    this -> codNaveAsignada = codNaveAsignada;
    this -> edad = edad;
    this -> nivelPrisionero = nivelPrisionero;
}
Prisionero::~Prisionero(){}
string Prisionero::getCodPrisionero(){
    return this -> codPrisionero;
}