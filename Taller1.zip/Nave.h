
#pragma once
#include <string>
using namespace std;
#include "Prisionero.h"
class Nave{
    public :
        Nave();
        Nave(string codNave, string nomNave, string codPlanetaDestino,int cantActualTripulante , int cantMaxTripulante);
        ~Nave();
        string getCodNave();
    private :
        string codNave;
        string nomNave;
        string codPlanetaDestino;
        int cantActualTripulante;
        int cantMaxTripulante;
        Prisionero* prisioneros;

};