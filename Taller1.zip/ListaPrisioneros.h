#pragma once
#include "Prisionero.h"

class ListaPrisioneros{
    public :
        ListaPrisioneros();
        ListaPrisioneros(int max);
        ~ListaPrisioneros();

        void desplegarPrisioneros();
        Prisionero buscarPrisionero(string codPrisionero);
        bool existe(string codPrisionero);
        bool agregarPrisionero(Prisionero prisionero);
        bool transferirPrisionero(Prisionero prisionero);
        bool moverPrisionero(Prisionero prisionero);
        
    private :
        Prisionero* lista;
        int cant;
        int max;
};