#include <iostream>
#include "Prisionero.h" // Importo la clase "Prisinero"
#include "Nave.h"
using namespace std;

Nave::Nave(){}
Nave::Nave(string codNave, string nomNave,string codPlanetaDestino, int cantActualTripulante, int cantMaxTripulante ){
    this -> codNave = codNave;
    this -> nomNave = nomNave;
    this -> codPlanetaDestino = codPlanetaDestino;
    this -> cantActualTripulante = cantActualTripulante;
    this -> cantMaxTripulante = cantMaxTripulante;
    prisioneros = new Prisionero[cantMaxTripulante];
}
Nave::~Nave(){}
string Nave::getCodNave(){
    return this -> codNave;
