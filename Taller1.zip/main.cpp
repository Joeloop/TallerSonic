#include <iostream>
using namespace std;
int opcion,opcion2,opcion3; 
bool salir = true;
bool salir2 = true;

int main() {
    while(salir){
        cout << "Bienvenido al Menú Principal !\n1) Agregar un dato nuevo \n2) Listado de prisioneros \n3) Manejar prisioneros \n4) Manejar Destinos Naves \n5) Estadísticas \n6) Salir\n";
        cin >> opcion;
        switch (opcion){
            case 1 :
                salir2 = true;
                while(salir2){
                    cout << "Escoja una opción\n 1.1) Prisionero\n 1.2) Nave\n 1.3) Planeta\n 1.4) Volver al menú Principal\n";
                    cin >> opcion2;
                    switch(opcion2){
                        case 1 :
                            break;
                        case 2 :
                            break;             
                        case 3 :
                            break;
                        case 4 :
                            salir2 = false;
                            break;
                    }
                }
            case 2 :
                break; 
            case 3 :
                salir2 = true;
                while(salir2){
                    cout << "Escoja una opción \n 3.1) Asignar Nave a un prisionero\n 3.2) Mover de una nave a otra a un prisionero\n 3.3) Volver al menú Principal\n";
                    cin >> opcion3;
                    switch(opcion3){
                        case 1 :
                            break;
                        case 2 :
                            break;
                        case 3 :
                            salir2 = false;
                            break;
                    }
                }
                break;
            case 4 :
                break;
            case 5 :
                break;
            case 6 :
                salir = false;
                break;
        }
    }
    cout << "El programa ha terminado"; 
}

