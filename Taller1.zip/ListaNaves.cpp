#include <iostream>
#include "ListaNaves.h"
using namespace std;

ListaNaves::ListaNaves(){}
ListaNaves::ListaNaves(int max){
    lista = new Nave[max];
    cant = 0;
    this -> max = max;
}
ListaNaves::~ListaNaves(){}