#pragma once
#include "Nave.h"

class ListaNaves{
public :
    ListaNaves();
    ListaNaves(int max);
    ~ListaNaves();

    bool agregarNave(string codNave);
    bool manejarNave();
private :
    Nave* lista;
    int cant;
    int max;
};