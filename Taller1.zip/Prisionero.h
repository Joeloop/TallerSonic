#pragma once
#include <string>
using namespace std;

class Prisionero{
public :
    Prisionero();
    Prisionero(string codPrisionero, string nombrePrisionero , string codNaveAsignada, int edad, int nivelPrisionero);
    ~Prisionero();

    string getCodPrisionero(); 
private:
    string codPrisionero;
    string nombrePrisionero;        
    string codNaveAsignada;
    int edad;
    int nivelPrisionero;
};