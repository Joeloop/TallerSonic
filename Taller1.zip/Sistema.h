#pragma once
#include "Prisionero.h"
#include "ListaPrisioneros.h"
#include "Nave.h"
#include "ListaNaves.h"
#include "Planeta.h"
#include "ListaPlanetas.h"
#include <string>

class Sistema{
public :
    Sistema(){}
    Sistema(int maxPrisioneros, int maxNaves, int maxPlanetas){}
    ~Sistema(){}
    void leerArchivo();
    
private:
    ListaNaves* naves;
    ListaPlanetas* planetas;
    ListaPrisioneros* prisioneros;
}
