#include <iostream>
#include "ListaPlanetas.h"
using namespace std;

ListaPlanetas::ListaPlanetas(){}
ListaPlanetas::ListaPlanetas(int max){
    lista = new Planeta[max];
    cant = 0;
    this -> max = max;
}
ListaPlanetas::~ListaPlanetas() {}
bool ListaPlanetas::existe(string idPlaneta){
    for(int i = 0 ; i < cant ; i++ ){
        if(lista[i].getCodPlaneta() == idPlaneta ){
            return true;
        }
    }
    return false;
}

bool ListaPlanetas::agregarPlaneta(Planeta planeta){
    if (cant == max){
        return false;
    }else{
        if(existe(planeta.getCodPlaneta())){
            return false;
        }else{
            lista[cant] = planeta;
            cant++;
        }
    }
}
