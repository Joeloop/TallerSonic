#include <iostream>
#include "ListaPrisioneros.h"
using namespace std;

ListaPrisioneros::ListaPrisioneros(){}
ListaPrisioneros::ListaPrisioneros(int max){
    lista = new Prisionero[max];
    cant = 0;
    this -> max = max;
}
ListaPrisioneros::~ListaPrisioneros(){}

Prisionero ListaPrisioneros::buscarPrisionero(string codPrisionero){
    for(int i = 0 ; i < cant ;i++){
        if(lista[i].getCodPrisionero() == codPrisionero){
            return lista[i];
        }
    }
}

bool ListaPrisioneros::existe(string codPrisionero){
    for(int i = 0 ;i < cant  ;i++ ){
        if(lista[i].getCodPrisionero() == codPrisionero ){
            return true;
        }
    }
    return false;
}

bool ListaPrisioneros::agregarPrisionero(Prisionero prisionero){
    if (cant == max){
        return false;
    }else{
        if(existe(prisionero.getCodPrisionero())){
            return false;
        }else{
            lista[cant] = prisionero;
            cant++;
        }
    }
}
